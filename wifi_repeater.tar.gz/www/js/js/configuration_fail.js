$(function () {
    setTimeout(function () {
        window.location.href = "wifi_setting.html";
    },2000)
})
