$(function () {
    $(".progress-ring").loadingRing();
});