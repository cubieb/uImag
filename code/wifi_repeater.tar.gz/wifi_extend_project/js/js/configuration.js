$(function () {
    $.ajax({
        type: "POST",
        url: "/cgi-bin/wifi_setting.cgi",
        // wifiData是指被选中的wifi的相关信息
        data: "if_success=success",
        timeout : 10000,
        complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
            console.log("提交表单数据成功后服务端返回的数据------------" + XMLHttpRequest);
            console.log("提交表单数据成功后服务端返回的数据------------" + status);
            //超时的情况下代表着与服务端密码验证成功
            //输入正确的主路由的密码进入statue为timeout的情况
            if(status=='timeout'){//超时,status还有success,error等值的情况
                console.log("已经超时，表明已经与主路由连接上了");
            }
            //在10秒钟内有反应
            if(status=='error'){
                console.log("error");
            }
            //输入错误的主路由的密码进入statue为success的情况
            if(status=='success'){
                console.log("success");
                window.location.href = "configuration_fail.html";
            }
        }
    });

    //返回按钮
    $("header>.nav-back").on("click", function () {
        window.history.go(-1);
    });

    setTimeout(function () {
        window.location.href = "configuration_success.html";
    },30000);
});