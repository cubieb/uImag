$(function () {

    //返回按钮
    $("header>.nav-back").on("click", function () {
        window.history.go(-1);
    });

    // setTimeout(function () {
    //     window.location.href = "configuration_success.html";
    // },30000);

    function checkConnect() {
    }
});