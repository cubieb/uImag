$(function () {
    var isChosen = $.isEmptyObject(JSON.parse(localStorage.getItem('ChosenWifi')));
    if (!isChosen) {
        //拿到配置界面保存的被选中的wifi信息列表
        var objStr = localStorage.getItem("ChosenWifi");
        var obj = JSON.parse(objStr);//此处向服务端请求来的是被选中的wifi的所有信息，是一个对象格式的。
        console.log(obj);
        //初始化路由设置界面的路由名称(Chosen是wifi_setting页面提交过来的，包括配置界面的主路由的所有信息和用户输入的正确密码)
        $("#wifiName").val(obj.newWifiName);
        //初始化路由设置界面的路由密码（wifiPwd是输入的主路由的密码）
        $("#wifiPwd").val(obj.newPassword);
        //设置wifi密码和主路由密码是否相同
        $("#samePwd").prop("checked", obj.wzcheckedVal);
        //设置管理密码和wifi密码是否相同
        $("#manageSamePwd").prop("checked", obj.wmcheckedVal);
        //设置模式选择
        var objId = $(obj.id);
        objId.prop("checked", true);
    }

    //返回按钮
    $("header>.nav-back").on("click", function () {
        window.history.go(-1);
    });


    //写校验规则
    $("#main>form").validate({
        rules: {
            wifiName: {
                emptyCheck: true,
                minlength: 1,
                maxlength: 26
            },
            wifiPwd: {
                emptyCheck: true,
                manageCodeCheck: true,
            }
        },
        messages: {
            wifiName: {
                emptyCheck: "输入不能为空",
            },
            wifiPwd: {
                emptyCheck: "输入不能为空",
                manageCodeCheck: "有效密码为8-64位字符",
            }
        },
        //成功验证，label指的是发生错误时那个标签，就是上面例子中的span（element），是p的子元素
        success: function (label) {
            label.parent().parent().css({"border-color": "#ddd"});
        },
        //其中error是字符串，保存了messages中返回的错误信息，
        // element是验证失败的input元素。
        errorPlacement: function (error, element) {
            console.log(element);
            console.log(error);
            error.appendTo(element.siblings("p"));
            element.parent().css({"border-color": "#EE2222"});
        },
        // onfocusout:false
    });

    //确定按钮
    var $btn = $("#main>form>button>a");
    $btn.on("click", function () {
        // 点击下一步按钮，表单验证通过后，提交数据并且跳转到下一页
        var isBoolean = $("#main>form").valid();
        console.log(isBoolean);
        if (isBoolean) {
            //提交当前的路由信息和密码
            $.ajax({
                type: "POST",
                url: "/cgi-bin/wifi_setting.cgi",//需要服务端的请求的地址
                data: "ex_station=station" + "&" + $("#main>form").serialize(),//需要哪些数据
                error: function (response) {
                    console.log("提交当前路由设置信息失败");
                },
                success: function (response) {
                    console.log(response);//请返回wifiSuccess
                    console.log("提交当前wifi设置信息成功");

                    var obj = {};
                    obj["newWifiName"] = $("#wifiName").val();
                    obj["newPassword"] = $("#wifiName").val();
                    obj["wmcheckedVal"] = $("#samePwd").prop("checked");//wifi密码与管理密码是否相同
                    if ($("#wifiName").val() == $("#wifiName").val()) {//wifi密码与主路由密码是否相同
                        obj["wzcheckedVal"] = true;
                    } else {
                        obj["wzcheckedVal"] = false;
                    }
                    //获取被选中的radio的checked值
                    var $label = $("#pattern .online-info-pattern label");
                    $label.on("click", function () {
                        var $checked = $(this).find("input[type='radio']").prop("checked");
                        if ($checked == true) {
                            var id = $(this).find("input[type='radio']").attr("id");
                            obj["id"] = id;
                        }
                    });

                    console.log(obj);
                    var objStr = JSON.stringify(obj);
                    localStorage.setItem("ChosenWifi", objStr);

                    //后端返回的是"wifiSuccess"
                    if (response == "wifiSuccess") {
                        //执行取消操作，进去重启放大器的过程
                        $.ajax({
                            type: "POST",
                            url: "/cgi-bin/sys_setting.cgi",//请求的接口数据，拿到上网的人的信息
                            data: "reboot_sys=reboot",
                            error: function () {
                                console.log("开始重启系统......失败！");
                            },
                            success: function (response) {
                                console.log("开始重启系统......成功！");
                                console.log(response);
                                if (response == "reboot") {
                                    window.location.href = "syetem_reboot_progress.html";
                                }
                            }
                        });
                    }
                }
            })
        }
        return false;
    })
})